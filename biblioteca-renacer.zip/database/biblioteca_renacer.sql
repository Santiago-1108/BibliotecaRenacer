-- Crear base de datos
CREATE DATABASE IF NOT EXISTS biblioteca_renacer;
USE biblioteca_renacer;

-- Tabla de administradores
CREATE TABLE administrators (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de estudiantes
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    identification VARCHAR(20) UNIQUE NOT NULL,
    address VARCHAR(200) NOT NULL,
    grade INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de libros
CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(100) NOT NULL,
    publisher VARCHAR(100) NOT NULL,
    category ENUM('niños', 'matematicas', 'español', 'sociales', 'culturales', 'quimica', 'fisica', 'deportes', 'cuentos', 'ciencias', 'ingles', 'religion', 'etica') NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    book_condition ENUM('bueno', 'regular', 'malo') NOT NULL DEFAULT 'bueno',
    summary TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de préstamos
CREATE TABLE loans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    book_id INT NOT NULL,
    loan_date DATE NOT NULL,
    return_date DATE NULL,
    status ENUM('active', 'returned', 'overdue') NOT NULL DEFAULT 'active',
    returned_book_condition ENUM('bueno', 'regular', 'malo') NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);

-- Insertar administrador por defecto
INSERT INTO administrators (name, username, password) VALUES 
('Administrador Principal', 'admin', 'admin123');

-- Insertar algunos estudiantes de ejemplo
INSERT INTO students (name, identification, address, grade) VALUES 
('Juan Pérez', '12345678', 'Calle 123 #45-67', 10),
('María García', '87654321', 'Carrera 89 #12-34', 9),
('Carlos López', '11223344', 'Avenida 56 #78-90', 11),
('Ana Rodríguez', '44332211', 'Calle 98 #76-54', 8);

-- Insertar algunos libros de ejemplo
INSERT INTO books (title, author, publisher, category, quantity, book_condition, summary) VALUES 
('Cien años de soledad', 'Gabriel García Márquez', 'Editorial Sudamericana', 'español', 3, 'bueno', 'Una obra maestra de la literatura latinoamericana que narra la historia de la familia Buendía.'),
('Álgebra Básica', 'Dr. Roberto Martínez', 'Editorial Educativa', 'matematicas', 5, 'bueno', 'Libro de texto para el aprendizaje de álgebra básica y ecuaciones lineales.'),
('Historia de Colombia', 'Prof. Carmen Silva', 'Editorial Nacional', 'sociales', 4, 'regular', 'Recorrido por la historia de Colombia desde la época precolombina hasta la actualidad.'),
('El Principito', 'Antoine de Saint-Exupéry', 'Editorial Juventud', 'cuentos', 6, 'bueno', 'Un cuento filosófico que ha cautivado a lectores de todas las edades.'),
('Química General', 'Dr. Luis Fernández', 'Editorial Científica', 'quimica', 3, 'bueno', 'Fundamentos de química para estudiantes de bachillerato.'),
('English Grammar', 'Sarah Johnson', 'Oxford Press', 'ingles', 4, 'bueno', 'Gramática inglesa con ejercicios prácticos para estudiantes intermedios.'),
('Cuentos para Niños', 'Varios Autores', 'Editorial Infantil', 'niños', 8, 'bueno', 'Colección de cuentos clásicos adaptados para niños.'),
('Física Moderna', 'Dr. Alberto Ruiz', 'Editorial Técnica', 'fisica', 2, 'regular', 'Introducción a los conceptos de física moderna y mecánica cuántica.'),
('Ética y Valores', 'Prof. Elena Morales', 'Editorial Humanística', 'etica', 5, 'bueno', 'Reflexiones sobre ética, moral y valores en la sociedad contemporánea.'),
('Ciencias Naturales', 'Dr. Miguel Torres', 'Editorial Escolar', 'ciencias', 6, 'bueno', 'Estudio integral de las ciencias naturales para educación secundaria.');

-- Insertar algunos préstamos de ejemplo
INSERT INTO loans (student_id, book_id, loan_date, status) VALUES 
(1, 1, '2024-01-15', 'active'),
(2, 4, '2024-01-20', 'active'),
(3, 6, '2024-01-10', 'active'),
(1, 7, '2024-01-05', 'returned'),
(4, 2, '2024-01-25', 'active');

-- Actualizar algunos préstamos como devueltos
UPDATE loans SET return_date = '2024-01-12', status = 'returned', returned_book_condition = 'bueno' WHERE id = 4;

-- Crear índices para mejorar el rendimiento
CREATE INDEX idx_students_identification ON students(identification);
CREATE INDEX idx_loans_student_id ON loans(student_id);
CREATE INDEX idx_loans_book_id ON loans(book_id);
CREATE INDEX idx_loans_status ON loans(status);
CREATE INDEX idx_books_category ON books(category);
CREATE INDEX idx_books_condition ON books(book_condition);
