document.addEventListener("DOMContentLoaded", () => {
  // Check if user is logged in
  const user = JSON.parse(sessionStorage.getItem("user"))
  if (!user || user.type !== "admin") {
    window.location.href = "../index.html"
    return
  }

  // Set admin name
  document.getElementById("adminName").textContent = user.name

  // Navigation
  const navItems = document.querySelectorAll(".sidebar-nav li[data-page]")
  const pages = document.querySelectorAll(".page")

  navItems.forEach((item) => {
    item.addEventListener("click", function () {
      const pageId = this.getAttribute("data-page")

      // Update active nav item
      navItems.forEach((nav) => nav.classList.remove("active"))
      this.classList.add("active")

      // Show selected page, hide others
      pages.forEach((page) => {
        if (page.id === pageId) {
          page.style.display = "block"
        } else {
          page.style.display = "none"
        }
      })
    })
  })

  // Logout
  document.getElementById("logoutBtn").addEventListener("click", () => {
    sessionStorage.removeItem("user")
    window.location.href = "../index.html"
  })

  // Load dashboard data
  loadDashboardData()

  // Books management
  const addBookBtn = document.getElementById("addBookBtn")
  const bookModal = document.getElementById("bookModal")
  const bookForm = document.getElementById("bookForm")
  const closeBtns = document.querySelectorAll(".close, .close-modal")

  addBookBtn.addEventListener("click", () => {
    document.getElementById("bookModalTitle").textContent = "Agregar Nuevo Libro"
    bookForm.reset()
    document.getElementById("bookId").value = ""
    bookModal.style.display = "block"
  })

  bookForm.addEventListener("submit", (e) => {
    e.preventDefault()
    saveBook()
  })

  // Students management
  const addStudentBtn = document.getElementById("addStudentBtn")
  const studentModal = document.getElementById("studentModal")
  const studentForm = document.getElementById("studentForm")

  addStudentBtn.addEventListener("click", () => {
    document.getElementById("studentModalTitle").textContent = "Agregar Nuevo Estudiante"
    studentForm.reset()
    document.getElementById("studentId").value = ""
    studentModal.style.display = "block"
  })

  studentForm.addEventListener("submit", (e) => {
    e.preventDefault()
    saveStudent()
  })

  // Loans management
  const newLoanBtn = document.getElementById("newLoanBtn")
  const loanModal = document.getElementById("loanModal")
  const loanForm = document.getElementById("loanForm")

  newLoanBtn.addEventListener("click", () => {
    loadStudentsForLoan()
    loadBooksForLoan()
    document.getElementById("loanDate").valueAsDate = new Date()
    loanModal.style.display = "block"
  })

  loanForm.addEventListener("submit", (e) => {
    e.preventDefault()
    saveLoan()
  })

  // Returns management
  const returnForm = document.getElementById("returnForm")

  returnForm.addEventListener("submit", (e) => {
    e.preventDefault()
    saveReturn()
  })

  // Close modals
  closeBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      bookModal.style.display = "none"
      studentModal.style.display = "none"
      loanModal.style.display = "none"
      document.getElementById("returnModal").style.display = "none"
    })
  })

  // Search and filter functionality
  document.getElementById("bookSearch").addEventListener("input", () => {
    filterBooks()
  })

  document.getElementById("categoryFilter").addEventListener("change", () => {
    filterBooks()
  })

  document.getElementById("studentSearch").addEventListener("input", () => {
    filterStudents()
  })

  document.getElementById("gradeFilter").addEventListener("change", () => {
    filterStudents()
  })

  document.getElementById("loanSearch").addEventListener("input", () => {
    filterLoans()
  })

  document.getElementById("returnSearch").addEventListener("input", () => {
    filterReturns()
  })

  // Load initial data
  loadBooks()
  loadStudents()
  loadLoans()
  loadReturns()

  // Reports functionality
  document
    .getElementById("pendingReturnsReport")
    .querySelector("button")
    .addEventListener("click", () => {
      generatePendingReturnsReport()
    })

  document
    .getElementById("bookInventoryReport")
    .querySelector("button")
    .addEventListener("click", () => {
      generateBookInventoryReport()
    })

  document
    .getElementById("damagedBooksReport")
    .querySelector("button")
    .addEventListener("click", () => {
      generateDamagedBooksReport()
    })

  document
    .getElementById("loanHistoryReport")
    .querySelector("button")
    .addEventListener("click", () => {
      generateLoanHistoryReport()
    })
})

// Dashboard functions
function loadDashboardData() {
  // Fetch dashboard statistics
  fetch("../php/dashboard.php")
    .then((response) => response.json())
    .then((data) => {
      document.getElementById("totalBooks").textContent = data.totalBooks
      document.getElementById("totalStudents").textContent = data.totalStudents
      document.getElementById("activeLoans").textContent = data.activeLoans
      document.getElementById("damagedBooks").textContent = data.damagedBooks

      // Load recent activity
      const activityTable = document.getElementById("recentActivityTable")
      activityTable.innerHTML = ""

      data.recentActivity.forEach((activity) => {
        const row = document.createElement("tr")
        row.innerHTML = `
                    <td>${activity.student_name}</td>
                    <td>${activity.book_title}</td>
                    <td>${activity.action}</td>
                    <td>${activity.date}</td>
                `
        activityTable.appendChild(row)
      })
    })
    .catch((error) => console.error("Error loading dashboard data:", error))
}

// Books functions
function loadBooks() {
  fetch("../php/books.php")
    .then((response) => response.json())
    .then((data) => {
      const booksTable = document.getElementById("booksTable")
      booksTable.innerHTML = ""

      data.forEach((book) => {
        const row = document.createElement("tr")
        row.innerHTML = `
                    <td>${book.id}</td>
                    <td>${book.title}</td>
                    <td>${book.author}</td>
                    <td>${book.publisher}</td>
                    <td>${book.category}</td>
                    <td>${book.quantity}</td>
                    <td>${getConditionBadge(book.condition)}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn-edit" data-id="${book.id}"><i class="fas fa-edit"></i></button>
                            <button class="btn-delete" data-id="${book.id}"><i class="fas fa-trash"></i></button>
                        </div>
                    </td>
                `
        booksTable.appendChild(row)
      })

      // Add event listeners to edit and delete buttons
      document.querySelectorAll(".btn-edit").forEach((btn) => {
        btn.addEventListener("click", function () {
          editBook(this.getAttribute("data-id"))
        })
      })

      document.querySelectorAll(".btn-delete").forEach((btn) => {
        btn.addEventListener("click", function () {
          deleteBook(this.getAttribute("data-id"))
        })
      })
    })
    .catch((error) => console.error("Error loading books:", error))
}

function saveBook() {
  const bookId = document.getElementById("bookId").value
  const bookData = {
    title: document.getElementById("bookTitle").value,
    author: document.getElementById("bookAuthor").value,
    publisher: document.getElementById("bookPublisher").value,
    category: document.getElementById("bookCategory").value,
    quantity: document.getElementById("bookQuantity").value,
    condition: document.getElementById("bookCondition").value,
    summary: document.getElementById("bookSummary").value,
  }

  const url = "../php/books.php"
  const method = bookId ? "PUT" : "POST"

  if (bookId) {
    bookData.id = bookId
  }

  fetch(url, {
    method: method,
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(bookData),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        document.getElementById("bookModal").style.display = "none"
        loadBooks()
        loadDashboardData()
      } else {
        alert("Error: " + data.message)
      }
    })
    .catch((error) => console.error("Error saving book:", error))
}

function editBook(id) {
  fetch(`../php/books.php?id=${id}`)
    .then((response) => response.json())
    .then((book) => {
      document.getElementById("bookModalTitle").textContent = "Editar Libro"
      document.getElementById("bookId").value = book.id
      document.getElementById("bookTitle").value = book.title
      document.getElementById("bookAuthor").value = book.author
      document.getElementById("bookPublisher").value = book.publisher
      document.getElementById("bookCategory").value = book.category
      document.getElementById("bookQuantity").value = book.quantity
      document.getElementById("bookCondition").value = book.condition
      document.getElementById("bookSummary").value = book.summary

      document.getElementById("bookModal").style.display = "block"
    })
    .catch((error) => console.error("Error loading book details:", error))
}

function deleteBook(id) {
  if (confirm("¿Está seguro de que desea eliminar este libro?")) {
    fetch(`../php/books.php?id=${id}`, {
      method: "DELETE",
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          loadBooks()
          loadDashboardData()
        } else {
          alert("Error: " + data.message)
        }
      })
      .catch((error) => console.error("Error deleting book:", error))
  }
}

function filterBooks() {
  const searchTerm = document.getElementById("bookSearch").value.toLowerCase()
  const categoryFilter = document.getElementById("categoryFilter").value

  const rows = document.querySelectorAll("#booksTable tr")
  rows.forEach((row) => {
    const title = row.cells[1]?.textContent.toLowerCase() || ""
    const author = row.cells[2]?.textContent.toLowerCase() || ""
    const category = row.cells[4]?.textContent.toLowerCase() || ""

    const matchesSearch = title.includes(searchTerm) || author.includes(searchTerm)
    const matchesCategory = !categoryFilter || category === categoryFilter

    row.style.display = matchesSearch && matchesCategory ? "" : "none"
  })
}

// Students functions
function loadStudents() {
  fetch("../php/students.php")
    .then((response) => response.json())
    .then((data) => {
      const studentsTable = document.getElementById("studentsTable")
      studentsTable.innerHTML = ""

      data.forEach((student) => {
        const row = document.createElement("tr")
        row.innerHTML = `
                    <td>${student.id}</td>
                    <td>${student.name}</td>
                    <td>${student.identification}</td>
                    <td>${student.grade}°</td>
                    <td>${student.address}</td>
                    <td>${student.active_loans || 0}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn-edit" data-id="${student.id}"><i class="fas fa-edit"></i></button>
                            <button class="btn-delete" data-id="${student.id}"><i class="fas fa-trash"></i></button>
                        </div>
                    </td>
                `
        studentsTable.appendChild(row)
      })

      // Add event listeners
      document.querySelectorAll("#studentsTable .btn-edit").forEach((btn) => {
        btn.addEventListener("click", function () {
          editStudent(this.getAttribute("data-id"))
        })
      })

      document.querySelectorAll("#studentsTable .btn-delete").forEach((btn) => {
        btn.addEventListener("click", function () {
          deleteStudent(this.getAttribute("data-id"))
        })
      })
    })
    .catch((error) => console.error("Error loading students:", error))
}

function saveStudent() {
  const studentId = document.getElementById("studentId").value
  const studentData = {
    name: document.getElementById("studentName").value,
    identification: document.getElementById("studentIdentification").value,
    address: document.getElementById("studentAddress").value,
    grade: document.getElementById("studentGrade").value,
  }

  const url = "../php/students.php"
  const method = studentId ? "PUT" : "POST"

  if (studentId) {
    studentData.id = studentId
  }

  fetch(url, {
    method: method,
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(studentData),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        document.getElementById("studentModal").style.display = "none"
        loadStudents()
        loadDashboardData()
      } else {
        alert("Error: " + data.message)
      }
    })
    .catch((error) => console.error("Error saving student:", error))
}

function editStudent(id) {
  fetch(`../php/students.php?id=${id}`)
    .then((response) => response.json())
    .then((student) => {
      document.getElementById("studentModalTitle").textContent = "Editar Estudiante"
      document.getElementById("studentId").value = student.id
      document.getElementById("studentName").value = student.name
      document.getElementById("studentIdentification").value = student.identification
      document.getElementById("studentAddress").value = student.address
      document.getElementById("studentGrade").value = student.grade

      document.getElementById("studentModal").style.display = "block"
    })
    .catch((error) => console.error("Error loading student details:", error))
}

function deleteStudent(id) {
  if (confirm("¿Está seguro de que desea eliminar este estudiante?")) {
    fetch(`../php/students.php?id=${id}`, {
      method: "DELETE",
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          loadStudents()
          loadDashboardData()
        } else {
          alert("Error: " + data.message)
        }
      })
      .catch((error) => console.error("Error deleting student:", error))
  }
}

function filterStudents() {
  const searchTerm = document.getElementById("studentSearch").value.toLowerCase()
  const gradeFilter = document.getElementById("gradeFilter").value

  const rows = document.querySelectorAll("#studentsTable tr")
  rows.forEach((row) => {
    const name = row.cells[1]?.textContent.toLowerCase() || ""
    const identification = row.cells[2]?.textContent.toLowerCase() || ""
    const grade = row.cells[3]?.textContent.replace("°", "") || ""

    const matchesSearch = name.includes(searchTerm) || identification.includes(searchTerm)
    const matchesGrade = !gradeFilter || grade === gradeFilter

    row.style.display = matchesSearch && matchesGrade ? "" : "none"
  })
}

// Loans functions
function loadLoans() {
  fetch("../php/loans.php")
    .then((response) => response.json())
    .then((data) => {
      const loansTable = document.getElementById("loansTable")
      loansTable.innerHTML = ""

      data.forEach((loan) => {
        const row = document.createElement("tr")
        row.innerHTML = `
                    <td>${loan.id}</td>
                    <td>${loan.student_name}</td>
                    <td>${loan.book_title}</td>
                    <td>${loan.loan_date}</td>
                    <td>${loan.return_date || "Pendiente"}</td>
                    <td>${getStatusBadge(loan.status)}</td>
                    <td>
                        <div class="action-buttons">
                            ${loan.status === "active" ? `<button class="btn-view" onclick="returnBook(${loan.id})"><i class="fas fa-undo"></i></button>` : ""}
                        </div>
                    </td>
                `
        loansTable.appendChild(row)
      })
    })
    .catch((error) => console.error("Error loading loans:", error))
}

function loadStudentsForLoan() {
  fetch("../php/students.php")
    .then((response) => response.json())
    .then((data) => {
      const select = document.getElementById("loanStudent")
      select.innerHTML = '<option value="">Seleccionar estudiante</option>'

      data.forEach((student) => {
        const option = document.createElement("option")
        option.value = student.id
        option.textContent = `${student.name} (${student.identification})`
        select.appendChild(option)
      })
    })
    .catch((error) => console.error("Error loading students for loan:", error))
}

function loadBooksForLoan() {
  fetch("../php/books.php?available=true")
    .then((response) => response.json())
    .then((data) => {
      const select = document.getElementById("loanBook")
      select.innerHTML = '<option value="">Seleccionar libro</option>'

      data.forEach((book) => {
        if (book.available_quantity > 0) {
          const option = document.createElement("option")
          option.value = book.id
          option.textContent = `${book.title} - ${book.author} (Disponibles: ${book.available_quantity})`
          select.appendChild(option)
        }
      })
    })
    .catch((error) => console.error("Error loading books for loan:", error))
}

function saveLoan() {
  const loanData = {
    student_id: document.getElementById("loanStudent").value,
    book_id: document.getElementById("loanBook").value,
    loan_date: document.getElementById("loanDate").value,
  }

  fetch("../php/loans.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(loanData),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        document.getElementById("loanModal").style.display = "none"
        loadLoans()
        loadBooks()
        loadDashboardData()
      } else {
        alert("Error: " + data.message)
      }
    })
    .catch((error) => console.error("Error saving loan:", error))
}

function returnBook(loanId) {
  fetch(`../php/loans.php?id=${loanId}`)
    .then((response) => response.json())
    .then((loan) => {
      document.getElementById("returnLoanId").value = loan.id
      document.getElementById("returnStudentName").value = loan.student_name
      document.getElementById("returnBookTitle").value = loan.book_title
      document.getElementById("returnDate").valueAsDate = new Date()

      document.getElementById("returnModal").style.display = "block"
    })
    .catch((error) => console.error("Error loading loan details:", error))
}

function saveReturn() {
  const returnData = {
    loan_id: document.getElementById("returnLoanId").value,
    return_date: document.getElementById("returnDate").value,
    book_condition: document.getElementById("returnBookCondition").value,
  }

  fetch("../php/returns.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(returnData),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        document.getElementById("returnModal").style.display = "none"
        loadLoans()
        loadReturns()
        loadBooks()
        loadDashboardData()
      } else {
        alert("Error: " + data.message)
      }
    })
    .catch((error) => console.error("Error saving return:", error))
}

function loadReturns() {
  fetch("../php/returns.php")
    .then((response) => response.json())
    .then((data) => {
      const returnsTable = document.getElementById("returnsTable")
      returnsTable.innerHTML = ""

      data.forEach((returnItem) => {
        const row = document.createElement("tr")
        row.innerHTML = `
                    <td>${returnItem.loan_id}</td>
                    <td>${returnItem.student_name}</td>
                    <td>${returnItem.book_title}</td>
                    <td>${returnItem.loan_date}</td>
                    <td>${returnItem.return_date}</td>
                    <td>${getConditionBadge(returnItem.book_condition)}</td>
                    <td>Devuelto</td>
                `
        returnsTable.appendChild(row)
      })
    })
    .catch((error) => console.error("Error loading returns:", error))
}

function filterLoans() {
  const searchTerm = document.getElementById("loanSearch").value.toLowerCase()

  const rows = document.querySelectorAll("#loansTable tr")
  rows.forEach((row) => {
    const student = row.cells[1]?.textContent.toLowerCase() || ""
    const book = row.cells[2]?.textContent.toLowerCase() || ""

    const matches = student.includes(searchTerm) || book.includes(searchTerm)
    row.style.display = matches ? "" : "none"
  })
}

function filterReturns() {
  const searchTerm = document.getElementById("returnSearch").value.toLowerCase()

  const rows = document.querySelectorAll("#returnsTable tr")
  rows.forEach((row) => {
    const student = row.cells[1]?.textContent.toLowerCase() || ""
    const book = row.cells[2]?.textContent.toLowerCase() || ""

    const matches = student.includes(searchTerm) || book.includes(searchTerm)
    row.style.display = matches ? "" : "none"
  })
}

// Reports functions
function generatePendingReturnsReport() {
  fetch("../php/reports.php?type=pending_returns")
    .then((response) => response.json())
    .then((data) => {
      displayReport("Estudiantes con Libros Pendientes", data)
    })
    .catch((error) => console.error("Error generating report:", error))
}

function generateBookInventoryReport() {
  fetch("../php/reports.php?type=book_inventory")
    .then((response) => response.json())
    .then((data) => {
      displayReport("Inventario de Libros", data)
    })
    .catch((error) => console.error("Error generating report:", error))
}

function generateDamagedBooksReport() {
  fetch("../php/reports.php?type=damaged_books")
    .then((response) => response.json())
    .then((data) => {
      displayReport("Libros Dañados", data)
    })
    .catch((error) => console.error("Error generating report:", error))
}

function generateLoanHistoryReport() {
  fetch("../php/reports.php?type=loan_history")
    .then((response) => response.json())
    .then((data) => {
      displayReport("Historial de Préstamos", data)
    })
    .catch((error) => console.error("Error generating report:", error))
}

function displayReport(title, data) {
  const reportResult = document.getElementById("reportResult")
  reportResult.innerHTML = `
        <h2>${title}</h2>
        <div class="report-content">
            ${generateReportTable(data)}
        </div>
    `
}

function generateReportTable(data) {
  if (!data || data.length === 0) {
    return "<p>No hay datos para mostrar.</p>"
  }

  const headers = Object.keys(data[0])
  let table = "<table><thead><tr>"

  headers.forEach((header) => {
    table += `<th>${header.replace("_", " ").toUpperCase()}</th>`
  })

  table += "</tr></thead><tbody>"

  data.forEach((row) => {
    table += "<tr>"
    headers.forEach((header) => {
      table += `<td>${row[header]}</td>`
    })
    table += "</tr>"
  })

  table += "</tbody></table>"
  return table
}

// Utility functions
function getConditionBadge(condition) {
  const badges = {
    bueno: '<span class="badge badge-success">Bueno</span>',
    regular: '<span class="badge badge-warning">Regular</span>',
    malo: '<span class="badge badge-danger">Malo</span>',
  }
  return badges[condition] || condition
}

function getStatusBadge(status) {
  const badges = {
    active: '<span class="badge badge-warning">Activo</span>',
    returned: '<span class="badge badge-success">Devuelto</span>',
    overdue: '<span class="badge badge-danger">Vencido</span>',
  }
  return badges[status] || status
}
