<?php
require_once 'config.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            // Get all returns
            $stmt = $pdo->query("
                SELECT l.id as loan_id, l.loan_date, l.return_date,
                       s.name as student_name, b.title as book_title,
                       l.returned_book_condition as book_condition
                FROM loans l
                JOIN students s ON l.student_id = s.id
                JOIN books b ON l.book_id = b.id
                WHERE l.status = 'returned'
                ORDER BY l.return_date DESC
            ");
            echo json_encode($stmt->fetchAll());
            break;
            
        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Update loan with return information
            $stmt = $pdo->prepare("
                UPDATE loans 
                SET return_date = ?, status = 'returned', returned_book_condition = ?
                WHERE id = ?
            ");
            
            $result = $stmt->execute([
                $data['return_date'],
                $data['book_condition'],
                $data['loan_id']
            ]);
            
            // Update book condition if it's damaged
            if ($data['book_condition'] === 'malo') {
                $stmt = $pdo->prepare("
                    UPDATE books b
                    JOIN loans l ON b.id = l.book_id
                    SET b.book_condition = 'malo'
                    WHERE l.id = ?
                ");
                $stmt->execute([$data['loan_id']]);
            }
            
            echo json_encode(['success' => $result]);
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
