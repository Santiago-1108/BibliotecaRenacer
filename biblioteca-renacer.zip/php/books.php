<?php
require_once 'config.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            if (isset($_GET['id'])) {
                // Get single book
                $stmt = $pdo->prepare("SELECT *, book_condition as condition FROM books WHERE id = ?");
                $stmt->execute([$_GET['id']]);
                $book = $stmt->fetch();
                echo json_encode($book);
            } elseif (isset($_GET['available'])) {
                // Get available books with quantity
                $stmt = $pdo->query("
                    SELECT b.*, 
                           (b.quantity - COALESCE(active_loans.count, 0)) as available_quantity
                    FROM books b
                    LEFT JOIN (
                        SELECT book_id, COUNT(*) as count 
                        FROM loans 
                        WHERE status = 'active' 
                        GROUP BY book_id
                    ) active_loans ON b.id = active_loans.book_id
                    WHERE b.book_condition != 'malo'
                ");
                echo json_encode($stmt->fetchAll());
            } else {
                // Get all books
                $stmt = $pdo->query("SELECT *, book_condition as condition FROM books ORDER BY title");
                echo json_encode($stmt->fetchAll());
            }
            break;
            
        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            
            $stmt = $pdo->prepare("
                INSERT INTO books (title, author, publisher, category, quantity, book_condition, summary) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            
            $result = $stmt->execute([
                $data['title'],
                $data['author'],
                $data['publisher'],
                $data['category'],
                $data['quantity'],
                $data['book_condition'],
                $data['summary']
            ]);
            
            echo json_encode(['success' => $result]);
            break;
            
        case 'PUT':
            $data = json_decode(file_get_contents('php://input'), true);
            
            $stmt = $pdo->prepare("
                UPDATE books 
                SET title = ?, author = ?, publisher = ?, category = ?, quantity = ?, book_condition = ?, summary = ?
                WHERE id = ?
            ");
            
            $result = $stmt->execute([
                $data['title'],
                $data['author'],
                $data['publisher'],
                $data['category'],
                $data['quantity'],
                $data['book_condition'],
                $data['summary'],
                $data['id']
            ]);
            
            echo json_encode(['success' => $result]);
            break;
            
        case 'DELETE':
            $id = $_GET['id'];
            
            // Check if book has active loans
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM loans WHERE book_id = ? AND status = 'active'");
            $stmt->execute([$id]);
            $activeLoans = $stmt->fetch()['count'];
            
            if ($activeLoans > 0) {
                echo json_encode(['success' => false, 'message' => 'No se puede eliminar un libro con préstamos activos']);
                break;
            }
            
            $stmt = $pdo->prepare("DELETE FROM books WHERE id = ?");
            $result = $stmt->execute([$id]);
            
            echo json_encode(['success' => $result]);
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
